﻿namespace GradesPrototype.Data
{
    // Types of user
    public enum Role { Teacher, Student };
}
