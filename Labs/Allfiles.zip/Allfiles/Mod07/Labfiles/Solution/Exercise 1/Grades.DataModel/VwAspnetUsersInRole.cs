﻿using System;
using System.Collections.Generic;

namespace Grades.DataModel;

public partial class VwAspnetUsersInRole
{
    public Guid UserId { get; set; }

    public Guid RoleId { get; set; }
}
