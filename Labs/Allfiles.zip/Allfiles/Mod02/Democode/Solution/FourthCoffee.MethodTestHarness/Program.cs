﻿namespace FourthCoffee.MethodTestHarness
{
    class Program
    {
        static void Main(string[] args)
        {
            var utilities = new Utilities();

        }
    }
}
